package demo;

public class HelloWorld {
	
	public void print() {
		System.out.println("Welcome to Spring Framework");
	}

}