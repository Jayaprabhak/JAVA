package pack3;

import pack1.*;
public class accessSpecifier3 extends proaccessSpecifiers{
public static void main(String[] args) {
	accessSpecifier3 obj = new accessSpecifier3();
	obj.display();
}
}