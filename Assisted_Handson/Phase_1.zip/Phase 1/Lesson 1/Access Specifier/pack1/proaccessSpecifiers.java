package pack1;

public class proaccessSpecifiers {
protected void display() {
	System.out.println("You are using protected access specifiers");
}
}